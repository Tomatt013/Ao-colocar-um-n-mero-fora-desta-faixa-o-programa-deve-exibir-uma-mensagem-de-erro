import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite um número entre 1 e 12: ");
        int numero = scanner.nextInt();

        String mes;
        switch (numero) {
            case 1:
                mes = "Janeiro".toUpperCase();
                break;
            case 2:
                mes = "Fevereiro".toUpperCase();
                break;
            case 3:
                mes = "Março".toUpperCase();
                break;
            case 4:
                mes = "Abril".toUpperCase();
                break;
            case 5:
                mes = "Maio".toUpperCase();
                break;
            case 6:
                mes = "Junho".toUpperCase();
                break;
            case 7:
                mes = "Julho".toUpperCase();
                break;
            case 8:
                mes = "Agosto".toUpperCase();
                break;
            case 9:
                mes = "Setembro".toUpperCase();
                break;
            case 10:
                mes = "Outubro".toUpperCase();
                break;
            case 11:
                mes = "Novembro".toUpperCase();
                break;
            case 12:
                mes = "Dezembro".toUpperCase();
                break;
            default:
                mes = "mês inválido".toUpperCase();
                break;
        }

        System.out.println(mes);
    }
}